import mediapipe as mp

print("mp:", mp)
print("solutions:", mp.solutions)
print("type(solutions):", type(mp.solutions))
print("hands:", mp.solutions.hands)
print("drawing:", mp.solutions.drawing_utils)
