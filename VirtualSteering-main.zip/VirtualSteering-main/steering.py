import cv2
import mediapipe as mp
import keyinput

font = cv2.FONT_HERSHEY_SIMPLEX

mp_hands = mp.solutions.hands
mp_draw = mp.solutions.drawing_utils

cap = cv2.VideoCapture(0)

# ================== VERY STRICT THUMBS UP ==================
def is_thumbs_up(hand_landmarks):
    lm = hand_landmarks.landmark

    thumb_tip = lm[4]
    thumb_ip = lm[3]
    wrist = lm[0]

    index_tip, index_pip = lm[8], lm[6]
    middle_tip, middle_pip = lm[12], lm[10]
    ring_tip, ring_pip = lm[16], lm[14]
    pinky_tip, pinky_pip = lm[20], lm[18]

    thumb_up = (thumb_tip.y < thumb_ip.y - 0.03) and (thumb_tip.y < wrist.y - 0.05)

    index_down = index_tip.y > index_pip.y + 0.02
    middle_down = middle_tip.y > middle_pip.y + 0.02
    ring_down = ring_tip.y > ring_pip.y + 0.02
    pinky_down = pinky_tip.y > pinky_pip.y + 0.02

    return thumb_up and index_down and middle_down and ring_down and pinky_down

# ================== KEY STATE ==================
state = {"w": False, "a": False, "s": False, "d": False, "space": False}

def set_key(key, pressed):
    if pressed and not state[key]:
        keyinput.press_key(key)
        state[key] = True
    elif not pressed and state[key]:
        keyinput.release_key(key)
        state[key] = False

with mp_hands.Hands(
    max_num_hands=2,
    model_complexity=1,
    min_detection_confidence=0.7,
    min_tracking_confidence=0.7
) as hands:

    while True:
        success, image = cap.read()
        if not success:
            continue

        image = cv2.flip(image, 1)
        h, w, _ = image.shape

        rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        results = hands.process(rgb)

        hand_points = []
        thumbs_up_count = 0

        if results.multi_hand_landmarks:
            for hand_landmarks in results.multi_hand_landmarks:
                mp_draw.draw_landmarks(image, hand_landmarks, mp_hands.HAND_CONNECTIONS)

                cx = int(hand_landmarks.landmark[9].x * w)
                cy = int(hand_landmarks.landmark[9].y * h)

                hand_points.append((cx, cy))

                if is_thumbs_up(hand_landmarks):
                    thumbs_up_count += 1

        # ================== TARGET STATE ==================
        target = {"w": False, "a": False, "s": False, "d": False, "space": False}

        # ================== BOOST ==================
        if thumbs_up_count == 2:
            target["space"] = True
            cv2.putText(image, "BOOST", (50, 140), font, 1.2, (0,0,255), 3)

        # ================== DRIVING ==================
        if len(hand_points) == 2:
            # SORT hands by X (left to right) → THIS FIXES RANDOM FLIP
            hand_points.sort(key=lambda p: p[0])

            (lx, ly) = hand_points[0]  # left hand
            (rx, ry) = hand_points[1]  # right hand

            diff = ly - ry
            DEAD_ZONE = 50

            if abs(diff) < DEAD_ZONE:
                target["w"] = True
                cv2.putText(image, "FORWARD", (50, 50), font, 1, (0,255,0), 2)

            elif diff > 0:
                # Left hand lower → turn LEFT
                target["w"] = True
                target["a"] = True
                cv2.putText(image, "LEFT", (50, 50), font, 1, (0,255,0), 2)

            else:
                # Right hand lower → turn RIGHT
                target["w"] = True
                target["d"] = True
                cv2.putText(image, "RIGHT", (50, 50), font, 1, (0,255,0), 2)

        elif len(hand_points) == 1:
            target["s"] = True
            cv2.putText(image, "BACKWARD", (50, 50), font, 1, (0,255,0), 2)

        else:
            cv2.putText(image, "NO HANDS", (50, 50), font, 1, (0,0,255), 2)

        # ================== APPLY KEYS ==================
        for k in target:
            set_key(k, target[k])

        cv2.putText(image, f"Hands: {len(hand_points)}", (50, 100), font, 1, (255,0,0), 2)

        cv2.imshow("Virtual Steering", image)

        if cv2.waitKey(1) & 0xFF == ord("q"):
            break

# ================== CLEANUP ==================
for k in state:
    if state[k]:
        keyinput.release_key(k)

cap.release()
cv2.destroyAllWindows()
